import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Send, 
  ArrowUp,
  FileText, 
  FileSearch, 
  List, 
  Calendar,
  CheckSquare,
  Bot,
  Paperclip,
  Sparkles,
  Plus,
  ChevronDown,
  Edit3,
  BookOpen,
  ArrowLeft,
  Pen,
  Archive,
  ExternalLink,
  X,
  Maximize2,
  Minimize2,
  Mic,
  User
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

interface DocumentAIAssistantProps {
  trialId?: string;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  thinking?: string; // AI's reasoning/thought process
  sources?: Array<{ filename: string; category: string }>;
}

export default function DocumentAIAssistant({ trialId }: DocumentAIAssistantProps) {
  const [, navigate] = useLocation();
  const [message, setMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showMorePrompts, setShowMorePrompts] = useState(false);
  const [activeTab, setActiveTab] = useState("ai-assistant");
  const [pdfViewerOpen, setPdfViewerOpen] = useState(false);
  const [pdfViewerExpanded, setPdfViewerExpanded] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<{name: string, url: string, page?: number} | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  // If trialId is provided, we're in trial-specific mode; otherwise, search all trials
  const searchMode = trialId ? 'single' : 'all';
  const selectedTrialId = trialId || 'all';
  const [sourceModalOpen, setSourceModalOpen] = useState(false);
  
  useEffect(() => {
    console.log('sourceModalOpen state changed to:', sourceModalOpen);
  }, [sourceModalOpen]);
  const [selectedTrials, setSelectedTrials] = useState<string[]>(trialId ? [trialId] : []);
  const [activeTrials, setActiveTrials] = useState<string[]>(trialId ? [trialId] : []);
  const [selectedDocuments, setSelectedDocuments] = useState<number[]>([]);
  const [isAllDocumentsMode, setIsAllDocumentsMode] = useState(true); // Default to searching all documents
  const chatEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const chatMutation = trpc.documentAI.chat.useMutation();
  
  // Query all trials with documents
  const { data: trialsWithDocs } = trpc.documents.getTrialsWithDocuments.useQuery();
  
  // Query documents for all selected trials using a single query
  const { data: sourceDocumentsByTrial = {} } = trpc.documents.listMultipleTrials.useQuery(
    { trialIds: selectedTrials },
    { 
      enabled: selectedTrials.length > 0,
      refetchInterval: 2000, // Refetch every 2 seconds to keep status fresh
      refetchOnMount: 'always' // Always refetch when modal opens
    }
  );

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory, isLoading]);

  const handleSend = async () => {
    if (!message.trim() || isLoading) return;

    const userMessage = message.trim();
    setMessage("");
    
    // Add transition delay for smoother UX
    setIsTransitioning(true);
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const newUserMessage: ChatMessage = { role: 'user', content: userMessage };
    setChatHistory(prev => [...prev, newUserMessage]);
    setIsTransitioning(false);
    setIsLoading(true);

    try {
      // Send entire conversation history to maintain context
      // Pass selected documents to query specific documents
      const response = await chatMutation.mutateAsync({
        messages: [...chatHistory, newUserMessage].map(msg => ({
          role: msg.role,
          content: msg.content,
        })),
        // If in all documents mode, don't send documentIds (backend will search all)
        // If in filtered mode, send specific documentIds
        ...(!isAllDocumentsMode && selectedDocuments.length > 0 ? { documentIds: selectedDocuments.map(String) } : {})
      });

      setChatHistory(prev => [...prev, {
        role: 'assistant',
        content: response.message,
        thinking: response.thinking,
      }]);
    } catch (error) {
      console.error('Error in chat:', error);
      setChatHistory(prev => [...prev, {
        role: 'assistant',
        content: 'Sorry, I encountered an error while processing your message. Please try again.',
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handlePromptClick = (promptText: string) => {
    setMessage(promptText);
    textareaRef.current?.focus();
  };

  const handleOpenDocument = (docName: string, page?: number) => {
    setSelectedDocument({
      name: docName,
      url: 'https://pdfobject.com/pdf/sample.pdf', // Placeholder PDF
      page,
    });
    setPdfViewerOpen(true);
  };

  const handleClosePdfViewer = () => {
    setPdfViewerOpen(false);
    setPdfViewerExpanded(false);
    setSelectedDocument(null);
  };

  const suggestedPrompts = [
    { icon: FileText, text: "What happens at Visit 3?", color: "text-gray-500" },
    { icon: FileSearch, text: "Summarize inclusion criteria", color: "text-gray-500" },
    { icon: Calendar, text: "What are the visit windows?", color: "text-gray-500" },
    { icon: CheckSquare, text: "Generate Visit 1 checklist", color: "text-gray-500" },
  ];

  const renderTopNav = () => (
    <div className="bg-[#F9FAFB] px-8 py-4">
      <div className="bg-white rounded-lg border border-gray-200 px-6 py-3 flex items-center gap-6">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors text-xs"
        >
          <ArrowLeft className="w-4 h-4" />
          Dashboard
        </button>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveTab("ai-assistant")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-colors ${
              activeTab === "ai-assistant"
                ? "bg-blue-50 text-blue-600"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            <Bot className="w-4 h-4" />
            AI Assistant
          </button>
          <button
            onClick={() => setActiveTab("response-archive")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs transition-colors ${
              activeTab === "response-archive"
                ? "bg-blue-50 text-blue-600"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            <Archive className="w-4 h-4" />
            Response Archive
          </button>
        </div>
        <div className="ml-auto flex items-center gap-3">
          {/* Trial Selector */}

        </div>
      </div>
    </div>
  );

  // Empty State - Centered Layout
  if (chatHistory.length === 0) {
    return (
      <>
        {/* Source Modal */}
        <Dialog open={sourceModalOpen} onOpenChange={setSourceModalOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>View Document Sources</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {/* Trial Selector with Checkboxes */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Select Trials ({selectedTrials.length} selected)
                </label>
                <div className="border border-gray-200 rounded-md max-h-48 overflow-y-auto">
                  {trialsWithDocs && trialsWithDocs.length > 0 ? (
                    <div className="divide-y divide-gray-200">
                      {trialsWithDocs.map((trial) => (
                        <label key={trial.id} className="flex items-center p-3 hover:bg-gray-50 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={selectedTrials.includes(trial.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedTrials([...selectedTrials, trial.id]);
                              } else {
                                setSelectedTrials(selectedTrials.filter(t => t !== trial.id));
                              }
                            }}
                            className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                          />
                          <span className="ml-3 text-sm text-gray-900">{trial.name}</span>
                        </label>
                      ))}
                    </div>
                  ) : (
                    <div className="p-4 text-center text-gray-500">
                      No trials with documents available
                    </div>
                  )}
                </div>
              </div>

              {/* Document List */}
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Available Documents
                </label>
                <div className="border border-gray-200 rounded-md max-h-96 overflow-y-auto">
                  {selectedTrials.length === 0 ? (
                    <div className="p-4 text-center text-gray-500">
                      Select at least one trial to view documents
                    </div>
                  ) : Object.keys(sourceDocumentsByTrial).length > 0 ? (
                    <div className="space-y-4">
                      {selectedTrials.map(trialId => {
                        const docs = sourceDocumentsByTrial[trialId];
                        if (!docs || docs.length === 0) return null;
                        
                        return (
                          <div key={trialId} className="border-b border-gray-200 last:border-0 pb-4 last:pb-0">
                            <div className="px-3 py-2 bg-gray-50 font-medium text-sm text-gray-700">
                              {trialsWithDocs?.find(t => t.id === trialId)?.name || trialId} ({docs.length} document{docs.length !== 1 ? 's' : ''})
                            </div>
                            <div className="divide-y divide-gray-200">
                              {docs.map((doc: any) => (
                                <div key={doc.id} className="p-3 hover:bg-gray-50 flex items-center justify-between">
                                  <div className="flex items-center gap-3">
                                    <input
                                      type="checkbox"
                                      checked={selectedDocuments.includes(doc.id)}
                                      onChange={(e) => {
                                        if (e.target.checked) {
                                          setSelectedDocuments([...selectedDocuments, doc.id]);
                                        } else {
                                          setSelectedDocuments(selectedDocuments.filter(id => id !== doc.id));
                                        }
                                      }}
                                      className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                                    />
                                    <FileText className="h-4 w-4 text-gray-400" />
                                    <div>
                                      <div className="text-sm font-medium text-gray-900">{doc.filename}</div>
                                      <div className="text-xs text-gray-500">{doc.category}</div>
                                    </div>
                                  </div>
                                  <span className={`px-2 py-1 text-xs rounded ${
                                    doc.isIndexed 
                                      ? 'bg-green-50 text-green-700' 
                                      : 'bg-yellow-50 text-yellow-700'
                                  }`}>
                                    {doc.isIndexed ? 'Indexed' : 'Processing'}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="p-4 text-center text-gray-500">
                      No documents available for selected trial(s)
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-between items-center pt-4">
                <Button variant="outline" onClick={() => setSourceModalOpen(false)}>
                  Close
                </Button>
                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    onClick={() => {
                    if (selectedTrials[0]) {
                      navigate(`/trial/${selectedTrials[0]}#documents`);
                        setSourceModalOpen(false);
                      }
                    }}
                    disabled={selectedTrials.length === 0}
                  >
                    Go to Document Hub
                  </Button>
                  <Button
                    onClick={() => {
                      if (selectedDocuments.length === 0) {
                        toast.error('Please select at least one document');
                        return;
                      }
                      setIsAllDocumentsMode(false);
                      setActiveTrials(selectedTrials);
                      setSourceModalOpen(false);
                      toast.success(`Now querying ${selectedDocuments.length} selected document(s)`);
                    }}
                    disabled={selectedDocuments.length === 0}
                  >
                    Use Selected Documents ({selectedDocuments.length})
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      <div className="flex flex-col h-full">
        {renderTopNav()}
        <div className="flex-1 flex flex-col items-center px-6 pt-16 transition-opacity duration-500 ease-in-out" style={{opacity: isTransitioning ? 0 : 1}}>
          <div className="max-w-3xl w-full space-y-16">
            <div className="text-center space-y-2">
              <h1 className="text-3xl font-semibold text-gray-900">Themison AI</h1>
              <p className="text-gray-600">Ask questions about your trial documents and generate operational outputs</p>
            </div>

            {/* Search Scope Indicator */}
            <div className="flex items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2 text-xs text-gray-600">
                <FileSearch className="w-4 h-4" />
                {isAllDocumentsMode ? (
                  <span>Searching: <span className="font-medium text-gray-900">All Documents</span></span>
                ) : (
                  <span>Searching: <span className="font-medium text-gray-900">{selectedDocuments.length} selected document(s)</span> from {activeTrials.length} trial(s)</span>
                )}
              </div>
              {!isAllDocumentsMode && (
                <button
                  onClick={() => {
                    setIsAllDocumentsMode(true);
                    setSelectedDocuments([]);
                    setSelectedTrials([]);
                    setActiveTrials([]);
                    toast.success('Now searching all documents');
                  }}
                  className="text-xs text-blue-600 hover:text-blue-700 hover:underline"
                >
                  Clear filter
                </button>
              )}
            </div>

            {/* Input Area */}
            <div className="bg-white rounded-2xl px-4 pt-6 pb-3 space-y-4" style={{borderWidth: '1.5px', borderColor: '#f2f2f2', borderStyle: 'solid'}}>
              <Textarea
                ref={textareaRef}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about your protocol, amendments, or trial documents..."
                className="min-h-[100px] border-0 shadow-none resize-none focus-visible:ring-0 text-gray-700 placeholder:text-gray-400"
              />
              
              <div className="flex items-center mt-3 max-w-3xl mx-auto justify-between">
                <div className="flex items-center gap-2">
                  <button className="text-gray-500 hover:text-gray-700 bg-gray-100 hover:bg-accent/80 rounded-full p-1.5">
                    <Paperclip className="w-4 h-4" />
                  </button>
                  <button className="flex items-center gap-1.5 text-xs text-gray-600 hover:text-gray-900 bg-gray-100 hover:bg-accent/80 rounded-full px-2.5 py-1.5">
                    <Plus className="w-3.5 h-3.5" />
                    Add context
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <button className="flex items-center gap-1.5 text-xs text-gray-600 hover:text-gray-900 bg-gray-100 hover:bg-accent/80 rounded-full px-2.5 py-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    Auto
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                  <button className="text-gray-500 hover:text-gray-700 bg-gray-100 hover:bg-accent/80 rounded-full p-1.5">
                    <Mic className="w-4 h-4" />
                  </button>
                  <Button
                    onClick={handleSend}
                    disabled={!message.trim() || isLoading}
                    size="icon"
                    variant="ghost"
                    className="rounded-full text-white bg-blue-600 hover:bg-blue-700"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 -mt-12">
              <Button variant="ghost" className="text-sm" size="sm" style={{borderWidth: '1.5px', borderColor: '#f2f2f2', borderStyle: 'solid'}}>
                <Edit3 className="w-4 h-4 mr-2" />
                Create
              </Button>
              <Button 
                variant="outline" 
                className="text-sm" 
                size="sm" 
                style={{borderWidth: '1.5px', borderColor: '#f2f2f2', borderStyle: 'solid'}}
                onClick={() => {
                  console.log('Source button clicked, opening modal');
                  setSourceModalOpen(true);
                }}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Source
              </Button>
            </div>

            {/* Suggested Prompts */}
            <div className="space-y-3 mt-20">
              <p className="text-center text-sm text-gray-500">Explore what you can ask</p>
              <div className="grid grid-cols-4 gap-3">
                {suggestedPrompts.map((prompt, index) => (
                  <button
                    key={index}
                    onClick={() => handlePromptClick(prompt.text)}
                    className="bg-white rounded-lg p-4 text-left hover:scale-[1.02] transition-all group"
                    style={{borderWidth: '1.5px', borderColor: '#f2f2f2', borderStyle: 'solid'}}
                  >
                    <prompt.icon className={`w-6 h-6 mb-3 ${prompt.color} group-hover:text-blue-600`} />
                    <p className="text-sm text-gray-700 group-hover:text-gray-900">{prompt.text}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      </>
    );
  }

  // Chat State - Split Pane Layout
  return (
    <>
      {/* Source Modal */}
      <Dialog open={sourceModalOpen} onOpenChange={setSourceModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>View Document Sources</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Trial Selector with Checkboxes */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Select Trials ({selectedTrials.length} selected)
              </label>
              <div className="border border-gray-200 rounded-md max-h-48 overflow-y-auto">
                {trialsWithDocs && trialsWithDocs.length > 0 ? (
                  <div className="divide-y divide-gray-200">
                    {trialsWithDocs.map((trial) => (
                      <label key={trial.id} className="flex items-center p-3 hover:bg-gray-50 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedTrials.includes(trial.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedTrials([...selectedTrials, trial.id]);
                            } else {
                              setSelectedTrials(selectedTrials.filter(t => t !== trial.id));
                            }
                          }}
                          className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <span className="ml-3 text-sm text-gray-900">{trial.name}</span>
                      </label>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 text-center text-gray-500">
                    No trials with documents available
                  </div>
                )}
              </div>
            </div>

            {/* Document List */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Available Documents
              </label>
              <div className="border border-gray-200 rounded-md max-h-96 overflow-y-auto">
                {selectedTrials.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    Select at least one trial to view documents
                  </div>
                ) : Object.keys(sourceDocumentsByTrial).length > 0 ? (
                  <div className="space-y-4">
                    {selectedTrials.map(trialId => {
                      const docs = sourceDocumentsByTrial[trialId];
                      if (!docs || docs.length === 0) return null;
                      
                      return (
                        <div key={trialId} className="border-b border-gray-200 last:border-0 pb-4 last:pb-0">
                          <div className="px-3 py-2 bg-gray-50 font-medium text-sm text-gray-700">
                            {trialsWithDocs?.find(t => t.id === trialId)?.name || trialId} ({docs.length} document{docs.length !== 1 ? 's' : ''})
                          </div>
                          <div className="divide-y divide-gray-200">
                            {docs.map((doc: any) => (
                              <div key={doc.id} className="p-3 hover:bg-gray-50 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <input
                                    type="checkbox"
                                    checked={selectedDocuments.includes(doc.id)}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedDocuments([...selectedDocuments, doc.id]);
                                      } else {
                                        setSelectedDocuments(selectedDocuments.filter(id => id !== doc.id));
                                      }
                                    }}
                                    className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                                  />
                                  <FileText className="h-4 w-4 text-gray-400" />
                                  <div>
                                    <div className="text-sm font-medium text-gray-900">{doc.filename}</div>
                                    <div className="text-xs text-gray-500">{doc.category}</div>
                                  </div>
                                </div>
                                <span className={`px-2 py-1 text-xs rounded ${
                                  doc.isIndexed 
                                    ? 'bg-green-50 text-green-700' 
                                    : 'bg-yellow-50 text-yellow-700'
                                }`}>
                                  {doc.isIndexed ? 'Indexed' : 'Processing'}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-4 text-center text-gray-500">
                    No documents available for selected trial(s)
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center pt-4">
              <Button variant="outline" onClick={() => setSourceModalOpen(false)}>
                Close
              </Button>
              <div className="flex gap-2">
                <Button 
                  variant="outline"
                  onClick={() => {
                    if (selectedTrials[0]) {
                      navigate(`/trial/${selectedTrials[0]}#documents`);
                      setSourceModalOpen(false);
                    }
                  }}
                  disabled={selectedTrials.length === 0}
                >
                  Go to Document Hub
                </Button>
                <Button
                  onClick={() => {
                    if (selectedDocuments.length === 0) {
                      toast.error('Please select at least one document');
                      return;
                    }
                    setIsAllDocumentsMode(false);
                    setActiveTrials(selectedTrials);
                    setSourceModalOpen(false);
                    toast.success(`Now querying ${selectedDocuments.length} selected document(s)`);
                  }}
                  disabled={selectedDocuments.length === 0}
                >
                  Use Selected Documents ({selectedDocuments.length})
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    <div className="flex flex-col h-full overflow-hidden">
      {/* Fixed Top Nav */}
      <div className="flex-shrink-0">
        {renderTopNav()}
      </div>
      
      {/* Split Pane Container - fills remaining height */}
      <div className="flex-1 flex overflow-hidden relative transition-opacity duration-500 ease-in-out" style={{opacity: isTransitioning ? 0 : 1}}>
        {/* Left: Chat Area */}
        <div className={`flex flex-col transition-all duration-300 ${
          pdfViewerOpen && !pdfViewerExpanded ? 'w-1/2' : 'w-full'
        }`}>
          {/* Chat Messages Area */}
          <div className="flex-1 overflow-y-auto py-8">
            <div className="max-w-3xl mx-auto px-6 space-y-8">
              {chatHistory.map((msg, index) => (
                <div
                  key={index}
                  className={`space-y-3 ${msg.role === 'user' ? 'ml-auto max-w-[80%]' : ''}`}
                >
                  {/* Avatar and Label Row */}
                  <div className={`flex items-center gap-2 h-8 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      msg.role === 'user' ? 'bg-blue-100' : 'bg-gray-100'
                    }`}>
                      {msg.role === 'user' ? (
                        <User className="w-4 h-4 text-blue-600" />
                      ) : (
                        <Bot className="w-5 h-5 text-gray-600" />
                      )}
                    </div>
                    <span className="text-sm font-medium text-gray-900">
                      {msg.role === 'user' ? 'You' : 'Themison AI'}
                    </span>
                  </div>

                  {/* Message Content */}
                  <div className={`space-y-3 ${msg.role === 'user' ? 'text-right' : ''}`}>
                    
                    {/* Thoughts Section - Only for assistant messages with thinking */}
                    {msg.role === 'assistant' && msg.thinking && (
                      <details className="group mb-4">
                        <summary className="flex items-center gap-2 px-4 py-3 bg-white border border-gray-200 rounded-md cursor-pointer hover:bg-gray-50 transition-colors">
                          <Sparkles className="w-4 h-4 text-blue-500 flex-shrink-0" />
                          <span className="text-sm font-medium text-gray-700">Thoughts</span>
                          <ChevronDown className="w-4 h-4 text-gray-400 ml-auto group-open:rotate-180 transition-transform" />
                        </summary>
                        <div className="mt-2 px-4 py-3 bg-gray-50 border border-gray-200 rounded-md text-sm text-gray-600 whitespace-pre-wrap">
                          {msg.thinking}
                        </div>
                      </details>
                    )}
                    <div className="prose prose-base max-w-none break-words">
                      {msg.role === 'assistant' ? (
                        <ReactMarkdown
                          remarkPlugins={[remarkGfm]}
                          components={{
                            code({ node, inline, className, children, ...props }: any) {
                              const match = /language-(\w+)/.exec(className || '');
                              return !inline && match ? (
                                <SyntaxHighlighter
                                  style={vscDarkPlus}
                                  language={match[1]}
                                  PreTag="div"
                                  className="rounded-lg my-4"
                                  {...props}
                                >
                                  {String(children).replace(/\n$/, '')}
                                </SyntaxHighlighter>
                              ) : (
                                <code className="bg-gray-100 text-gray-800 px-1.5 py-0.5 rounded text-sm font-mono" {...props}>
                                  {children}
                                </code>
                              );
                            },
                            h1: ({ children }) => <h1 className="text-3xl font-bold mt-8 mb-6 text-gray-900">{children}</h1>,
                            h2: ({ children }) => <h2 className="text-2xl font-bold mt-8 mb-4 text-gray-900">{children}</h2>,
                            h3: ({ children }) => <h3 className="text-xl font-bold mt-6 mb-3 text-gray-900">{children}</h3>,
                            p: ({ children, node }) => {
                              // Check if this is the first paragraph by checking if it's the first element
                              const isFirstParagraph = node?.position?.start?.line === 1;
                              if (isFirstParagraph) {
                                return <p className="mb-6 leading-relaxed text-gray-900 text-base font-bold">{children}</p>;
                              }
                              return <p className="mb-5 leading-relaxed text-gray-700 text-sm">{children}</p>;
                            },
                            ul: ({ children }) => <ul className="list-disc list-inside mb-4 space-y-2">{children}</ul>,
                            ol: ({ children }) => <ol className="list-decimal list-inside mb-4 space-y-2">{children}</ol>,
                            li: ({ children }) => <li className="leading-relaxed">{children}</li>,
                            blockquote: ({ children }) => (
                              <blockquote className="border-l-4 border-blue-500 pl-4 py-2 my-4 italic text-gray-600 bg-blue-50 rounded-r">
                                {children}
                              </blockquote>
                            ),
                            a: ({ children, href }) => (
                              <a href={href} className="text-blue-600 hover:text-blue-700 underline" target="_blank" rel="noopener noreferrer">
                                {children}
                              </a>
                            ),
                            strong: ({ children }) => <strong className="font-semibold text-gray-900">{children}</strong>,
                            em: ({ children }) => <em className="italic">{children}</em>,
                          }}
                        >
                          {msg.content}
                        </ReactMarkdown>
                      ) : (
                        <div className="whitespace-pre-wrap break-words leading-relaxed bg-white px-4 py-3 rounded-lg text-sm">{msg.content}</div>
                      )}
                    </div>

                    {/* Source Citations */}
                    {msg.role === 'assistant' && msg.sources && msg.sources.length > 0 && (
                      <div className="mt-4 space-y-3">
                        {msg.sources.map((source, sourceIndex) => {
                          const borderColors = ['border-l-blue-500', 'border-l-green-500', 'border-l-orange-500', 'border-l-purple-500'];
                          const borderColor = borderColors[sourceIndex % borderColors.length];
                          
                          return (
                            <div
                              key={sourceIndex}
                              className={`bg-gray-50 border-l-4 ${borderColor} rounded-r-lg p-4 space-y-3`}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex items-center gap-2">
                                  <FileText className="w-5 h-5 text-gray-600" />
                                  <div>
                                    <p className="font-medium text-gray-900">{source.filename}</p>
                                    <p className="text-xs text-gray-500">Section "{source.category}"</p>
                                  </div>
                                </div>
                              </div>
                              <p className="text-sm text-gray-700 italic">
                                "At Visit 3, the subject must undergo a safety assessment including vital signs, physical examination, and review of adverse events. Blood samples must be collected according to the Schedule of Activities."
                              </p>
                              <button
                                onClick={() => handleOpenDocument(source.filename, 3)}
                                className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700"
                              >
                                Open in {source.filename}
                                <ExternalLink className="w-4 h-4" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* Loading State */}
              {isLoading && (
                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-gray-100">
                    <Bot className="w-5 h-5 text-gray-600" />
                  </div>
                  <div className="flex-1 space-y-3">
                    <div className="flex items-center h-8">
                      <span className="text-sm font-medium text-gray-900">Themison AI</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-500">
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
               )}
              <div ref={chatEndRef} />
            </div>
          </div>

          {/* Input Area - Fixed at Bottom */}
          <div className="flex-shrink-0 py-4 bg-gray-50">
            <div className="max-w-3xl mx-auto px-6">
              {/* Active Documents Indicator */}
              <div className="flex items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-1 text-xs text-gray-600 min-w-0 flex-1 overflow-hidden">
                  <FileSearch className="w-4 h-4 flex-shrink-0" />
                  <span className="flex-shrink-0">Searching:</span>
                  {isAllDocumentsMode ? (
                    <span className="font-medium text-gray-900 flex-shrink-0">All Documents</span>
                  ) : (
                    <span className="font-medium text-gray-900 truncate">{selectedDocuments.length} selected document(s) from {activeTrials.length} trial(s)</span>
                  )}
                </div>
                {!isAllDocumentsMode && (
                  <button
                    onClick={() => {
                      setIsAllDocumentsMode(true);
                      setSelectedDocuments([]);
                      setSelectedTrials([]);
                      setActiveTrials([]);
                      toast.success('Now searching all documents');
                    }}
                    className="text-xs text-blue-600 hover:text-blue-700 hover:underline flex-shrink-0 whitespace-nowrap"
                  >
                    Clear filter
                  </button>
                )}
              </div>
              {/* Create/Source Tabs - Only show in empty state (no messages) */}
              {chatHistory.length === 0 && (
                <div className="flex items-center gap-3 mb-3">
                  <Button 
                    variant="ghost" 
                    className="text-sm" 
                    size="sm"
                  >
                    <Pen className="w-4 h-4 mr-2" />
                    Create
                  </Button>
                  <Button 
                    variant="outline" 
                    className="text-sm" 
                    size="sm" 
                    style={{borderWidth: '1.5px', borderColor: '#f2f2f2', borderStyle: 'solid'}}
                    onClick={() => {
                      console.log('Source button clicked, opening modal');
                      setSourceModalOpen(true);
                    }}
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    Source
                  </Button>
                </div>
              )}
              {/* Input Box */}
              <div className="bg-white rounded-2xl px-4 pt-3 pb-3 space-y-3" style={{borderWidth: '1.5px', borderColor: '#f2f2f2', borderStyle: 'solid'}}>
                <Textarea
                  ref={textareaRef}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask a follow-up question..."
                  className="min-h-[80px] border-0 resize-none focus-visible:ring-0 focus-visible:border-0 shadow-none text-gray-700 placeholder:text-gray-400"
                />
                
                <div className="flex items-center mt-3 justify-between">
                  <div className="flex items-center gap-2">
                    <button className="text-gray-500 hover:text-gray-700 bg-gray-100 hover:bg-accent/80 rounded-full p-1.5">
                      <Paperclip className="w-4 h-4" />
                    </button>
                    <button className="flex items-center gap-1.5 text-xs text-gray-600 hover:text-gray-900 bg-gray-100 hover:bg-accent/80 rounded-full px-2.5 py-1.5">
                      <Plus className="w-3.5 h-3.5" />
                      Add context
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="flex items-center gap-1.5 text-xs text-gray-600 hover:text-gray-900 bg-gray-100 hover:bg-accent/80 rounded-full px-2.5 py-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      Auto
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                    <button className="text-gray-500 hover:text-gray-700 bg-gray-100 hover:bg-accent/80 rounded-full p-1.5">
                      <Mic className="w-4 h-4" />
                    </button>
                    <Button
                      onClick={handleSend}
                      disabled={!message.trim() || isLoading}
                      size="icon"
                      variant="ghost"
                      className="rounded-full text-white bg-blue-600 hover:bg-blue-700"
                    >
                      <ArrowUp className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: PDF Viewer Pane - Fixed Position */}
        {pdfViewerOpen && selectedDocument && !pdfViewerExpanded && (
          <div className="absolute top-0 right-0 w-1/2 h-full flex flex-col pt-0 pb-3 pr-6 pl-3">
            <div className="flex-1 bg-white flex flex-col rounded-xl overflow-hidden">
            {/* PDF Viewer Header */}
            <div className="flex items-center justify-between px-6 py-3 border-b border-gray-200 bg-white">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-gray-600" />
                <div>
                  <h3 className="font-semibold text-gray-900">{selectedDocument.name}</h3>
                  {selectedDocument.page && (
                    <p className="text-xs text-gray-500">Page {selectedDocument.page}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setPdfViewerExpanded(true)}
                  className="text-gray-600 hover:text-gray-900"
                >
                  <Maximize2 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleClosePdfViewer}
                  className="text-gray-600 hover:text-gray-900"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* PDF Content */}
            <div className="flex-1 overflow-hidden bg-gray-100">
              <iframe
                src={selectedDocument.url}
                className="w-full h-full"
                title={selectedDocument.name}
              />
            </div>
            </div>
          </div>
        )}

        {/* Expanded PDF Viewer (Full Screen) */}
        {pdfViewerOpen && selectedDocument && pdfViewerExpanded && (
          <div className="fixed inset-0 z-50 bg-white flex flex-col">
            {/* PDF Viewer Header */}
            <div className="flex items-center justify-between px-6 py-3 border-b border-gray-200 bg-white">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-gray-600" />
                <div>
                  <h3 className="font-semibold text-gray-900">{selectedDocument.name}</h3>
                  {selectedDocument.page && (
                    <p className="text-xs text-gray-500">Page {selectedDocument.page}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setPdfViewerExpanded(false)}
                  className="text-gray-600 hover:text-gray-900"
                >
                  <Minimize2 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleClosePdfViewer}
                  className="text-gray-600 hover:text-gray-900"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* PDF Content */}
            <div className="flex-1 overflow-hidden bg-gray-100">
              <iframe
                src={selectedDocument.url}
                className="w-full h-full"
                title={selectedDocument.name}
              />
            </div>
          </div>
        )}
      </div>
    </div>
    </>
  );
}
