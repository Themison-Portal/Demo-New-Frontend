/**
 * Sidebar Navigation Component
 * Design: Clinical Modernism - Systematic grid, cool clinical palette, Inter typography
 * Features: Three-state navigation (main menu, trial list, trial detail) with smooth transitions
 */

import { useState } from "react";
import { useSidebar } from "@/contexts/SidebarContext";
import { useDemoState } from "@/contexts/DemoStateContext";
import { useSidebarNav } from "@/contexts/SidebarNavContext";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { 
  Home, 
  FileText, 
  LayoutGrid, 
  Building, 
  Puzzle, 
  Bell, 
  Settings,
  Search,
  ChevronDown,
  ChevronRight,
  PanelLeftClose,
  PanelLeft,
  ArrowLeft,
  Upload,
  Plus,
  Calendar,
  MessageSquare,
  Check
} from "lucide-react";
import { MessageChatSquare } from "@/components/icons/MessageChatSquare";
import { TrialElements } from "@/components/icons/TrialElements";
import { AnalyticsIcon } from "@/components/icons/AnalyticsIcon";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

interface NavItem {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
  hasArrow?: boolean;
  onClick?: () => void;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export function Sidebar() {
  const [location] = useLocation();
  const { resetDemo, loadSampleData, loadFullDataset, getCurrentDataMode } = useDemoState();
  const currentDataMode = getCurrentDataMode();
  // Get trials from database
  const { data: dbTrials = [] } = trpc.trials.list.useQuery();
  
  // Map database trials to sidebar format
  const trials = dbTrials.map((trial, index) => ({
    id: trial.id,
    name: trial.title,
    sponsor: trial.sponsor || 'No sponsor',
    status: trial.status,
    phase: trial.phase || 'Not set',
    enrolled: trial.enrolledPatients || 0,
    target: trial.targetPatients || 0,
    color: getTrialColor(index),
  }));
  
  // Generate consistent colors for trials
  function getTrialColor(index: number) {
    const colors = ['#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#06B6D4', '#EC4899', '#6366F1'];
    return colors[index % colors.length];
  }
  const { navState, isCollapsed, openTrialList, openTrialDetail, backToMain, backToTrialList } = useSidebarNav();
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    type: 'reset' | 'sample' | 'full' | null;
  }>({ open: false, type: null });

  const handleSearchClick = () => {
    toast.info("Search feature coming soon");
  };



  const handleLoadSampleData = () => {
    setConfirmDialog({ open: false, type: null });
    loadSampleData();
    backToMain();
    toast.success("Sample data loaded (8 trials)");
  };

  const handleLoadFullDataset = () => {
    setConfirmDialog({ open: false, type: null });
    loadFullDataset();
    backToMain();
    toast.success("Full dataset loaded (25+ trials)");
  };

  const handleConfirmAction = () => {
    if (confirmDialog.type === 'reset') {
      handleResetDemo();
    } else if (confirmDialog.type === 'sample') {
      handleLoadSampleData();
    } else if (confirmDialog.type === 'full') {
      handleLoadFullDataset();
    }
  };

  const getConfirmDialogContent = () => {
    switch (confirmDialog.type) {
      case 'reset':
        return {
          title: 'Reset to Empty',
          description: 'Are you sure you want to reset all data? This will delete all trials, documents, tasks, and activity. This action cannot be undone.'
        };
      case 'sample':
        return {
          title: 'Load Sample Data',
          description: 'Are you sure you want to load sample data? This will replace all current data with 8 preset trials.'
        };
      case 'full':
        return {
          title: 'Load Full Dataset',
          description: 'Are you sure you want to load the full dataset? This will replace all current data with 25+ preset trials and extensive mock data.'
        };
      default:
        return { title: '', description: '' };
    }
  };

  const handleResetDemo = () => {
    setConfirmDialog({ open: false, type: null });
    resetDemo();
    backToMain();
    toast.success("Demo reset to empty state");
  };

  // Main menu navigation sections
  const mainMenuSections: NavSection[] = [
    {
      title: "GENERAL",
      items: [
        { label: "Dashboard", icon: Home, href: "/" },
        { 
          label: "Trial Workspace", 
          icon: TrialElements, 
          href: "/trial-workspace", 
          hasArrow: true,
          onClick: openTrialList 
        },
      ],
    },
    {
      title: "WORKSPACE",
      items: [
        { label: "Document AI Assistant", icon: FileText, href: "/documents" },
        { label: "Task Manager", icon: LayoutGrid, href: "/tasks" },
        { label: "Collaboration Hub", icon: MessageChatSquare, href: "/collaboration" },
        { label: "Analytics", icon: AnalyticsIcon, href: "/analytics" },
      ],
    },
    {
      title: "TEAM & ADMIN",
      items: [
        { label: "Organization", icon: Building, href: "/organization" },
        { label: "Integrations", icon: Puzzle, href: "/integrations" },
        { label: "Notifications", icon: Bell, href: "/notifications" },
      ],
    },
    {
      title: "CONFIGURATION",
      items: [
        { label: "Settings", icon: Settings, href: "/settings" },
      ],
    },
  ];

  // Render main menu
  const renderMainMenu = () => (
    <>
      {/* Navigation Sections */}
      <nav className="flex-1 overflow-y-auto px-3 pt-6 pb-2">
        {mainMenuSections.map((section, sectionIdx) => (
          <div key={section.title}>
            {sectionIdx > 0 && (
              <div className="my-4 border-t border-sidebar-border" />
            )}
            {!isCollapsed && (
              <h2 className="px-3 mb-2 text-xs font-semibold tracking-wider text-muted-foreground">
                {section.title}
              </h2>
            )}
            <div className="flex flex-col gap-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href;
                
                if (item.onClick) {
                  return (
                    <div
                      key={item.label}
                      onClick={item.onClick}
                      className={`
                        flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium
                        transition-all duration-150 ease-out cursor-pointer
                        text-sidebar-foreground hover:bg-[#E6E7EB]
                        ${isCollapsed ? "justify-center" : "justify-between"}
                      `}
                      title={isCollapsed ? item.label : undefined}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="h-4 w-4 flex-shrink-0" />
                        {!isCollapsed && <span>{item.label}</span>}
                      </div>
                      {!isCollapsed && item.hasArrow && (
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  );
                }
                
                return (
                  <Link key={item.href} href={item.href}>
                    <div
                      className={`
                        flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium
                        transition-all duration-150 ease-out cursor-pointer
                        ${
                          isActive
                            ? "bg-gray-100 text-primary"
                            : "text-sidebar-foreground hover:bg-[#E6E7EB]"
                        }
                        ${isCollapsed ? "justify-center" : ""}
                      `}
                      title={isCollapsed ? item.label : undefined}
                    >
                      <Icon className="h-4 w-4 flex-shrink-0" />
                      {!isCollapsed && <span>{item.label}</span>}
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
    </>
  );

  // Render trial list
  const renderTrialList = () => (
    <>
      {/* Back Button */}
      {!isCollapsed && (
        <div className="px-4 py-4">
          <Button
            variant="ghost"
            className="w-full justify-start gap-2 text-sm font-medium text-muted-foreground hover:text-foreground"
            onClick={backToMain}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Main
          </Button>
        </div>
      )}



      {/* Trial List */}
      <nav className="flex-1 overflow-y-auto px-3 pt-6 pb-2">
        {!isCollapsed && (
          <h2 className="px-3 mb-2 text-xs font-semibold tracking-wider text-muted-foreground">
            MY TRIALS ({trials?.length || 0})
          </h2>
        )}
        <div className="flex flex-col gap-1">
          {trials?.map((trial, index) => (
            <div
              key={trial.id}
              onClick={() => openTrialDetail(trial.id)}
              className={`flex items-start gap-3 rounded-md text-sm cursor-pointer transition-all duration-150 ease-out hover:bg-[#E6E7EB] ${
                isCollapsed ? "px-2 py-2 justify-center" : "px-3 py-3"
              }`}
              title={isCollapsed ? trial.name : undefined}
            >
              {isCollapsed ? (
                <div 
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 border transition-colors ${
                    navState.type === 'trial-detail' && navState.trialId === trial.id
                      ? 'bg-primary/10 text-primary border-primary/20'
                      : 'bg-white text-muted-foreground border-border hover:border-primary/40'
                  }`}
                >
                  {index + 1}
                </div>
              ) : (
                <>
                  <div 
                    className="w-2 h-2 rounded-full mt-0.5 flex-shrink-0" 
                    style={{ backgroundColor: trial.color }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sidebar-foreground truncate">
                      {trial.name}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {trial.sponsor} · {trial.status}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {trial.enrolled}/{trial.target} enrolled
                    </div>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </nav>
    </>
  );

  // Mock chat history data
  const mockChatHistory = [
    { id: 1, title: "Protocol amendment review", time: "2h ago" },
    { id: 2, title: "Patient enrollment discussion", time: "Yesterday" },
    { id: 3, title: "Site visit planning", time: "2 days ago" },
  ];

  // Render trial detail
  const renderTrialDetail = () => {
    if (navState.type !== 'trial-detail') return null;
    
    const trial = trials.find(t => t.id === navState.trialId);
    if (!trial) return null;

    return (
      <>
        {/* Back Button */}
        {!isCollapsed && (
          <div className="px-4 py-4">
            <Button
              variant="ghost"
              className="w-full justify-start gap-2 text-sm font-medium text-muted-foreground hover:text-foreground"
              onClick={backToTrialList}
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Trial List
            </Button>
          </div>
        )}

        {/* Trial Header */}
        {!isCollapsed && (
          <div className="px-4 pb-4">
            <div className="flex items-center gap-3 pl-3">
              <div 
                className="w-3 h-3 rounded-full flex-shrink-0" 
                style={{ backgroundColor: trial.color }}
              />
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sidebar-foreground truncate">
                  Trial {trial.id.toUpperCase()}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {trial.phase} · {trial.status}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Scrollable content area */}
        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {/* Recent Activity */}
          {!isCollapsed && (
            <div className="pb-4">
              <div className="border-t border-sidebar-border pt-4">
                <h3 className="text-xs font-semibold tracking-wider text-muted-foreground mb-2">
                RECENT ACTIVITY
              </h3>
              <div className="space-y-3 pl-3">
                <div className="text-xs">
                  <div className="text-sidebar-foreground">• Amendment 3 uploaded</div>
                  <div className="text-muted-foreground mt-0.5">2 hours ago</div>
                </div>
                <div className="text-xs">
                  <div className="text-sidebar-foreground">• Task completed</div>
                  <div className="text-muted-foreground mt-0.5">Yesterday</div>
                </div>
                <div className="text-xs">
                  <div className="text-sidebar-foreground">• New team member added</div>
                  <div className="text-muted-foreground mt-0.5">3 days ago</div>
                </div>
                <Button
                  variant="link"
                  size="sm"
                  className="h-auto p-0 text-xs text-primary"
                  onClick={() => toast.info("View all activity feature coming soon")}
                >
                  View all activity →
                </Button>
              </div>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          {!isCollapsed && (
            <div className="pb-4">
              <div className="border-t border-sidebar-border pt-4">
                <h3 className="text-xs font-semibold tracking-wider text-muted-foreground mb-2">
                  QUICK ACTIONS
                </h3>
                <div className="flex flex-col gap-1 -ml-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start gap-2 text-sm"
                    onClick={() => toast.info("Upload document feature coming soon")}
                  >
                    <Upload className="h-4 w-4" />
                    Upload Document
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start gap-2 text-sm"
                    onClick={() => toast.info("Create task feature coming soon")}
                  >
                    <Plus className="h-4 w-4" />
                    Create Task
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start gap-2 text-sm"
                    onClick={() => toast.info("Add member feature coming soon")}
                  >
                    <Plus className="h-4 w-4" />
                    Add Team Member
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start gap-2 text-sm"
                    onClick={() => toast.info("Schedule visit feature coming soon")}
                  >
                    <Calendar className="h-4 w-4" />
                    Schedule Visit
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Chat History */}
          {!isCollapsed && (
            <div className="pb-4">
              <div className="border-t border-sidebar-border pt-4">
                <h3 className="text-xs font-semibold tracking-wider text-muted-foreground mb-2">
                  CHAT HISTORY
                </h3>
                <div className="space-y-2 -ml-2">
                  {mockChatHistory.map((chat) => (
                    <div
                      key={chat.id}
                      className="flex items-start gap-2 px-2 py-2 rounded-md cursor-pointer hover:bg-[#E6E7EB] transition-colors"
                      onClick={() => toast.info("Chat history feature coming soon")}
                    >
                      <MessageSquare className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-sidebar-foreground truncate">
                          {chat.title}
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {chat.time}
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button
                    variant="link"
                    size="sm"
                    className="h-auto p-0 px-2 text-xs text-primary"
                    onClick={() => toast.info("View all chats feature coming soon")}
                  >
                    View all chats →
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </>
    );
  };

  return (
    <aside className={`fixed left-0 top-11 h-[calc(100vh-44px)] bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 ${
      isCollapsed ? "w-[64px]" : "w-[280px]"
    }`}>


      {/* Dynamic Content Based on Navigation State with Smooth Transitions */}
      <div className="flex-1 flex flex-col min-h-0 transition-opacity duration-500 ease-in-out">
        {navState.type === 'main' && (
          <div className="flex-1 flex flex-col min-h-0 animate-in fade-in slide-in-from-left-4 duration-500">
            {renderMainMenu()}
          </div>
        )}
        {navState.type === 'trial-list' && (
          <div className="flex-1 flex flex-col min-h-0 animate-in fade-in slide-in-from-right-4 duration-500">
            {renderTrialList()}
          </div>
        )}
        {navState.type === 'trial-detail' && (
          <div className="flex-1 flex flex-col min-h-0 animate-in fade-in slide-in-from-right-4 duration-500">
            {renderTrialDetail()}
          </div>
        )}
      </div>

      {/* Logo Footer - Fixed at bottom */}
      <div className={`border-t border-sidebar-border p-4 flex-shrink-0 flex items-center ${
        isCollapsed ? "justify-center" : "justify-start"
      }`}>
        {!isCollapsed && (
          <img 
            src="/images/themison-logo.svg" 
            alt="Themison" 
            className="h-3 w-auto"
          />
        )}
        {isCollapsed && (
          <div className="text-primary font-bold text-lg">T</div>
        )}
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog open={confirmDialog.open} onOpenChange={(open) => setConfirmDialog({ open, type: null })}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{getConfirmDialogContent().title}</AlertDialogTitle>
            <AlertDialogDescription>
              {getConfirmDialogContent().description}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmAction}>Confirm</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </aside>
  );
}
